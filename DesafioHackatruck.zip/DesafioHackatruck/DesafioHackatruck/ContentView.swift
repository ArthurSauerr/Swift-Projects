//
//  ContentView.swift
//  DesafioHackatruck
//
//  Created by Turma02-3 on 28/03/24.
//

import SwiftUI

struct ContentView: View {
    @State private var nome: String = ""
    @State private var showAlert = false
    var body: some View {
        VStack {
            HStack{
                Text("Bem-vindo, ").font(.title)
                Text(nome).font(.title)
            }
            TextField(
                "Insira seu nome",
                text: $nome
            ).multilineTextAlignment(.center)
        }
        ZStack{
            Image("fundo")
                .resizable()
                .scaledToFill()
                .blur(radius: 2.0)
                .opacity(0.2)
            VStack{
                Image("logo")
                    .resizable()
                    .frame(width: 280, height: 140)
                    .padding()
                    .shadow(radius: 20)
                Image("truck")
                    .resizable()
                    .frame(width: 240, height: 120)
            }
        }
        
        Button("Entrar") {
            showAlert = true
        }
        .alert(isPresented:$showAlert) {
                    Alert(
                        title: Text("AVISO"),
                        message: Text("Você irá começar o desafio agora!")
                    )
                }
        .padding()
    }
}

#Preview {
    ContentView()
}
