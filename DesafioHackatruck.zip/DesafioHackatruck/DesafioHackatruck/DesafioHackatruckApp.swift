//
//  DesafioHackatruckApp.swift
//  DesafioHackatruck
//
//  Created by Turma02-3 on 28/03/24.
//

import SwiftUI

@main
struct DesafioHackatruckApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
