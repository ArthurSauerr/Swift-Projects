//
//  Aula04App.swift
//  Aula04
//
//  Created by Turma02-3 on 01/04/24.
//

import SwiftUI

@main
struct Aula04App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
