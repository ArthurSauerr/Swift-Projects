//
//  ContentView.swift
//  Aula04
//
//  Created by Turma02-3 on 01/04/24.
//

import SwiftUI

struct ContentView: View {
    @State var valuePeso: Double = 0
    @State var valueAltura: Double = 0
    @State var total: Double = 0
    var body: some View {
        ZStack{
            
            if(total < 18.5){
                Color("baixo_peso").ignoresSafeArea()
            } else if(total >= 18.5 && total <= 24.99){
                Color("normal").ignoresSafeArea()
            } else if (total >= 25 && total <= 29.99){
                Color("sobrepeso").ignoresSafeArea()
            } else if(total >= 30){
                Color("obeso").ignoresSafeArea()
            }
            
            VStack{
                Text("Calculadora IMC")
                    .font(.title)
                    .fontWeight(.bold)
                Spacer()
            }
            VStack{
                Text("Peso")
                TextField("Insira o peso, em quilos", value: $valuePeso, formatter: NumberFormatter())
                    .keyboardType(.decimalPad)
                    .textContentType(.oneTimeCode)
                    .padding()
                    .background(Color.white.opacity(0.3))
                    .cornerRadius(10)
                Text("Altura")
                TextField("Insira a altura, em metros", value: $valueAltura, formatter: NumberFormatter())
                    .keyboardType(.decimalPad)
                    .textContentType(.oneTimeCode)
                    .padding()
                    .background(Color.white.opacity(0.3))
                    .cornerRadius(10)
                HStack{
                    Button("Calcular"){
                        total = valuePeso/(valueAltura * valueAltura)
                    }.colorMultiply(.black)
                    }
                .buttonStyle(.bordered)
                .padding()
                Text("Resultado: \(total)")
                VStack{
                    Image("tabela-IMC")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                }
                }
            .padding()
            }
            
        }
    }
    
    #Preview {
        ContentView()
    }
