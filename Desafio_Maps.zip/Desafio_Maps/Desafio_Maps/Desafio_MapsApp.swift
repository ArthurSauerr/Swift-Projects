//
//  Desafio_MapsApp.swift
//  Desafio_Maps
//
//  Created by Turma02-3 on 04/04/24.
//

import SwiftUI

@main
struct Desafio_MapsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
