//
//  ContentView.swift
//  Desafio_Maps
//
//  Created by Turma02-3 on 04/04/24.
//

import SwiftUI
import MapKit
import Foundation

struct Location : Identifiable{
    let id = UUID()
    let name : String
    let coordinate: CLLocationCoordinate2D
    let flag: String
    let description : String
}

struct SheetView: View {
    let selectedLocation: Location?
    
    var body: some View {
        VStack(spacing: 10) {
            Text(selectedLocation?.name ?? "None")
                .font(.title.bold())
            
            AsyncImage(url: URL(string: selectedLocation?.flag ?? "")) { image in
                image
                    .resizable()
                    .scaledToFit()
                    .frame(maxHeight: 200)
            } placeholder: {
                ProgressView()
            }
            
            Text(selectedLocation?.description ?? "None")
                .multilineTextAlignment(.center)
            Spacer()
        }
        .padding()
    }
}


struct ContentView: View {
    @State private var position = MapCameraPosition.region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: -14.20791, longitude: -51.37209),
            span: MKCoordinateSpan(latitudeDelta: 1, longitudeDelta: 1))
    )
    @State private var selectedLocation: Location? = nil
    @State private var searchText: String = ""
    @State private var showingSheet = false
    
    var locations = [
        Location(name: "Floripa 🏝️", coordinate: CLLocationCoordinate2D(latitude: -27.5954, longitude: -48.5480), flag: "https://upformaturas.com.br/wp-content/uploads/2020/10/floripa-conheca-mais-do-nosso-destino-de-viagem-de-formatura-capa-1.jpg", description: "Floripa, também conhecida como Florianópolis, é a capital do estado de Santa Catarina, no sul do Brasil. É famosa por suas praias deslumbrantes e sua rica cultura."),
        Location(name: "Tóquio 🇯🇵", coordinate: CLLocationCoordinate2D(latitude: 35.6895, longitude: 139.6917), flag: "https://www.telegraph.co.uk/content/dam/Travel/Destinations/Asia/Japan/Tokyo/Tokyo%20lead-xlarge.jpg", description: "Tóquio, a capital do Japão, é uma metrópole agitada conhecida por sua tecnologia de ponta, sua cultura pop vibrante e sua culinária única."),
        Location(name: "Kathmandu 🇳🇵", coordinate: CLLocationCoordinate2D(latitude: 27.7172, longitude: 85.3240), flag: "https://lh6.googleusercontent.com/proxy/U0mXrc9Ri93Nn5K4SvzWyZwOpqkKVrLquIrimaQi_aererHtFOXT26ESwSVId52Ds7IXFUi4vy2MGESPWv8OTNn3pEGspf84mvsEhPdX5ta5JEnwjsSP4yIutx7Z9CB-PTin9Yawph3oFtVMoryzN69VwxvPq4Z5Sw", description: "Katmandu é a capital e a maior cidade do Nepal. Situada no vale de Kathmandu, a cidade é conhecida por sua rica história cultural, arquitetura antiga e como ponto de partida para muitas expedições ao Himalaia."),
        Location(name: "Moscou 🇷🇺", coordinate: CLLocationCoordinate2D(latitude: 55.7558, longitude: 37.6173), flag: "https://static.politize.com.br/2022/03/pexels-photo-8285167-scaled.jpg", description: "Moscou, a capital da Rússia, é conhecida por seus icônicos pontos turísticos, como a Praça Vermelha, o Kremlin e a Catedral de São Basílio, bem como por sua rica história e cultura."),

    ]
    
    
    var body: some View {
        ZStack{
            Map(position: $position){
                ForEach(locations) { location in
                    Marker(location.name, coordinate: location.coordinate)
                }
            }
            .onTapGesture {
                showingSheet.toggle()
            }
            .sheet(isPresented: $showingSheet) {
                SheetView(selectedLocation: selectedLocation)
            }

            VStack{
                Rectangle()
                    .foregroundStyle(Color.white).ignoresSafeArea()
                    .frame(height: 100)
                    .opacity(0.6)
                    .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                    .overlay(Text("World Map\n")
                        .font(.title.bold())
                        .shadow(radius: 10))
                    .overlay(TextField("Local", text: $searchText)
                        .font(.title3.bold())
                        .multilineTextAlignment(.center)
                        .padding(.top, 30)
                        .shadow(radius: 10))
                Spacer()
                ScrollView(.horizontal) {
                    HStack(spacing: -10){
                        ForEach(locations) { location in
                            VStack(alignment: .leading) {
                                AsyncImage(url: URL(string: location.flag)) { image in
                                    image
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .onTapGesture {
                                            selectedLocation = location
                                            position = MapCameraPosition.region(
                                                MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
                                                                   ,span:
                                                                    MKCoordinateSpan(latitudeDelta: 1, longitudeDelta: 1))
                                            )
                                            searchText = location.name
                                            
                                        }
                                } placeholder: {
                                    ProgressView()
                                }
                                .frame(height: 130)
                                .cornerRadius(20)
                                .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                            }
                            .padding()
                        }
                    }
                }
            }
        }
    }
}


#Preview {
    ContentView()
}
