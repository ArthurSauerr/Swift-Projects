//
//  ContentView.swift
//  Aula05-2
//
//  Created by Turma02-3 on 02/04/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack{
        ZStack{
            Color("Background").ignoresSafeArea()
                //.zIndex(0)
            VStack {
                Image("logo")
                    .resizable()
                    .frame(width: 200, height: 100)
                Spacer()
            }

            VStack{
                NavigationLink(destination: SegundaTela()){
                    Text("Modo 1")
                }
                .foregroundStyle(Color.white)
                .font(.title2)
                .fontWeight(.bold)
                .frame(width: 200, height: 100)
                .background(Color.pink)
                .clipShape(RoundedRectangle(cornerSize: CGSize(width: 5, height: 5)))
                .shadow(radius: 20)
                NavigationLink(destination: TerceiraTela()){
                    Text("Modo 2")
                }
                .foregroundStyle(Color.white)
                .font(.title2)
                .fontWeight(.bold)
                .frame(width: 200, height: 100)
                .background(Color.pink)
                .clipShape(RoundedRectangle(cornerSize: CGSize(width: 5, height: 5)))
                .shadow(radius: 20)
                Button("Modo 3"){
                    
                }
                .foregroundStyle(Color.white)
                .font(.title2)
                .fontWeight(.bold)
                .frame(width: 200, height: 100)
                .background(Color.pink)
                .clipShape(RoundedRectangle(cornerSize: CGSize(width: 5, height: 5)))
                .shadow(radius: 20)
            }
            }
          //  .padding()
        }
    }
}

#Preview {
    ContentView()
}
