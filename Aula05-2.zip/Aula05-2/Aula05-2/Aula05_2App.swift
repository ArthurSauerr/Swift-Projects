//
//  Aula05_2App.swift
//  Aula05-2
//
//  Created by Turma02-3 on 02/04/24.
//

import SwiftUI

@main
struct Aula05_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
