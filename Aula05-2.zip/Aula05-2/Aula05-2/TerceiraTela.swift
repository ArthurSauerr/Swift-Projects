//
//  TerceiraTela.swift
//  Aula05-2
//
//  Created by Turma02-3 on 02/04/24.
//

import SwiftUI

struct TerceiraTela: View {
    var body: some View {
        ZStack{
            Color("Background").ignoresSafeArea()
            
            VStack{
                Text("Modo 1")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundStyle(Color.white)
                Spacer()
            }
            VStack{
                Rectangle()
                    .frame(width: 250, height: 200)
                    .foregroundStyle(Color.pink)
                    .clipShape(RoundedRectangle(cornerSize: CGSize(width: 5, height: 5)))
                    .shadow(radius: 20)
                    .overlay(Text("Nome: Arthur\nSobrenome: Sauer")
                        .foregroundStyle(Color.white))
                    .fontWeight(.bold)
            }
        }
    }
}

#Preview {
    TerceiraTela()
}
