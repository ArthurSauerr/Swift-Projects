//
//  CinzaView.swift
//  Aula05
//
//  Created by Turma02-3 on 02/04/24.
//

import SwiftUI

struct CinzaView: View {
    var body: some View {
        ZStack{
            Color("cinza").ignoresSafeArea()
            Circle()
                .frame(width: 300)
            Image(systemName: "paintpalette")
                .resizable()
                .frame(width: 200, height: 200)
                .foregroundStyle(Color("cinza"))
                
        }.padding(.bottom)
    }
}

#Preview {
    CinzaView()
}
