//
//  ListView.swift
//  Aula05
//
//  Created by Turma02-3 on 02/04/24.
//

import SwiftUI

struct ListView: View {
    var body: some View {
        VStack{
                Text("Lista").font(.title).fontWeight(.bold)
            List{
                Text("Item")
                Text("Item")
                Text("Item")
            }
        }
    }
}

#Preview {
    ListView()
}
