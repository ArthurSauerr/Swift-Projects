//
//  Aula05App.swift
//  Aula05
//
//  Created by Turma02-3 on 02/04/24.
//

import SwiftUI

@main
struct Aula05App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
