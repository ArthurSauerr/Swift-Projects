//
//  Aula06App.swift
//  Aula06
//
//  Created by Turma02-3 on 04/04/24.
//

import SwiftUI

@main
struct Aula06App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
