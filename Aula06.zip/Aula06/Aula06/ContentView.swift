//
//  ContentView.swift
//  Aula06
//
//  Created by Turma02-3 on 04/04/24.
//

import SwiftUI

struct Song : Identifiable{
    var id : Int
    var name : String
    var artist : String
    var capa : String
}

struct ContentView: View {
    var body: some View {
        var arrayMusicas = [
            Song(id: 1, name: "Californication", artist: "Red Hot Chilli Peppers", capa: "Playlist_foto"),
            Song(id: 2, name: "One", artist: "Metallica", capa: "Metallica_album"),
            Song(id: 3, name: "Everlong", artist: "Foofighters", capa: "Foofighters_album")
            
        ]
        ZStack{
            LinearGradient(gradient: Gradient(colors: [Color("SGreen"), Color.black]), startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            VStack{
                Image("Playlist_foto")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                    .padding(.top, 50)
                HStack{
                    Text("Rockzinho 🤘")
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                        .foregroundStyle(Color.white)
                        .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                        .padding()
                    Spacer()
                }
                VStack{
                    List(arrayMusicas){
                        s in Text(s.name)
                    }
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
